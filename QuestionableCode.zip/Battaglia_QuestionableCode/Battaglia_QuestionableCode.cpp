// QuestionableCode.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

// CppCheck shows includes are missing. NO RISK.
#include <cassert>
#include <iostream>
#include <numeric>
#include <set>
#include <vector>

// TODO: You are going to compare the warnings & errors between Visual Studio and CppCheck.
//  Make sure you are using CppCheck 2.1 or greater
//
//  1. Create a Visual Studio Console project with this file as the only file
//  2. Compile it and check the warning and errors
//  3. Create a CppCheck project to analyze a Visual Studio project with this file.
//  4. In CppCheck Edit / Preferences / General Tab: Set Display error id in column "Id", Enable inline suppressions, and Check for inconclusive errors also
//  5. In CppCheck View, Select Check All to ensure all types of checks are enabled
//  6. In CppCheck Analyze, set the C++ Standard to C++17, and Enforce C++
//  7. Make sure to run the analysis
//  8. Save the results to a file (XML format)
//  9. Take a screen shot of the Visual Studio Error list (all errors, warnings, and messages)
//  10. Identify all messages from CppCheck NOT identified in Visual Studio.
//      For each message not in both:
//        Identify the risk as: RISK or NOT RISK
//        Identify which system (Visual Studio or CppCheck) found the issue
//        Provide a couple of sentences describing the issue found

class C
{
    std::set<int> typedefs;
    bool is_type(int type) const
    {
        if (typedefs.find(type) != typedefs.end())
            return is_type(type); // BUG: endless recursion. FOUND BY PROGRAMMER. Enless recursion can cause program function to run indefinately. This may cause a crash.
        return false;
    }
};

class A
{
    int x; // <- RISK: Found in Both. Variable is not initialized which means there is allocated space in memory with no data value.
    A(const A& other) {} // Visual Studios shows the initialization error on this line.
};

class MySpecialType
{
public:
    int MyVal = 1;
    // CppCheck found a performance issue with member function being static. NO RISK
    void DontThrow() noexcept
    {
        throw "Ha! I threw anyway!"; // <- NO RISK: Found in Both. Exception was thrown even though it was specified that it won't. Undesireable but poses no risk.
    }
};

void foo(int** a)
{
    int b = 1;
    *a = &b; // RISK: Found by CppCheck. The function parameter is assigned the address of a local auto-variable. 
             // Local auto-variables are reserved from the stack which is freed when the function ends. So the pointer to a local variable is invalid after the function ends, which is Dangerous.
}

void work_with_arrays(int count)
{
    int buf[10]; // <- RISK
    if (count == 1000)
        buf[count] = 0; // <- ERROR <- RISK: Found in Both. Buffer overrun could affect other spaces in memory and cause undesireable behavior.
}

void do_something_useless()
{
    int sum = 0;
    for (auto i = 0; i < 1000; ++i)
    {
        sum += i;
    }

    std::cout << "I summed up " << sum << " as the answer." << std::endl;
}

void vector_test()
{
    std::vector<int> items;
    items.push_back(1);
    items.push_back(2);
    items.push_back(3);
    std::vector<int>::iterator iter;
    for (iter = items.begin(); iter != items.end(); ++iter) { // NO RISK: Found by CppCheck. local container "item" being used as an iterator may be invalid.
        if (*iter == 2) {
            items.erase(iter);
        }
    }
}

int a;
bool my_function()
{
    a = 1 + 2;
    return a; // NO RISK: Found by CppCheck. Variable being returned is a Non-boolean value. Function is to return bool type. Function may fail or return invalid value.
}

struct Token
{
    Token* next() { return nullptr; } // NO RISK: CppCheck found. Performance issue that will still compile but does not make sense conceptually.
};

int foo(Token* tok)
{
    while (tok);
    tok = tok->next(); // RISK: Found by CppCheck. the pointer argument is useless. Undereferenced pointers could pose a threat if exploited. Additonally, the value is never used for "tok" variable.

    return 0;
}

int main()
{
    std::vector<int> counts{ 1, 2, 3, 5 };
    int x = 0; // NO RISK: Found by CppCheck. Variable is not used. Initializing the variable will prevent garbage from being collected. Style issue.
    int y = 0; // NO RISK: Found by CppCheck. Variable is not used. Initializing the variable will prevent garbage from being collected. Style issue.
    int z = 0;

    std::cout << "Welcome to the Questionable Code Test!" << std::endl;

    //do_something_useless();

    work_with_arrays(10);

    assert(z = 2); // NO RISK: Found by CppCheck. The assert statement modifies the value. This code will most likely be removed when program is built. If it is needed in the build release this is a bug.

    assert(my_function() == 3); // <- RISK: Found in Both. Always false for boolean check causing the program to fail.

    try
    {
        int x = 5; // NO RISK: Found by CppCheck. This variable shadows a variable found outside of the local space.
        int y = 5; // NO RISK: Found by CppCheck. This variable shadows a variable found outside of the local space.
        int z = 5; // NO RISK: Found by CppCheck. This variable shadows a variable found outside of the local space.
        std::cout << "x + y + z = " << (x + y + z) << std::endl;
    }
    catch (...)
    {

    }

    int* c;
    foo(&c);

    vector_test();

    MySpecialType myobject;
    std::cout << "myobject.MyVal = " << myobject.MyVal << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu